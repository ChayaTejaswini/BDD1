# To run this Code :
Platform - Windows 7,windows 8,windows 10

# Minimum configuration :-
Processor - AMD PRO A4-3350B APU
System Type :- 64-bit Operating system




#Procedures:-
Step 1------>Enter into the project "TestvagrantCodingAssessment".
Step 2------>Click on src/test/java.
Step 3------>Click on the package of org.testvagrant.
Step 4------>Enter into the class called "ImdbAndWikiPagesValidation.java"
Step 5------>Run the Code.



#Additional Details:-
In src/main/java i have created the packages for genericUtilities and Objectrepositories.
This is the Screenshot of Validation Process----->!validatation ScreenShotpath(Screenshot 2022-11-15 190418.png)

